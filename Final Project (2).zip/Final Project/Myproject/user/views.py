from datetime import datetime
from re import search
from tkinter.font import names
from django.db.models import Q
from django.shortcuts import render
from.models import *
from datetime import datetime

from django.db import connection



from django.template.context_processors import request

from django.http import HttpResponse

# Create your views here.
def index(request):
    data=category.objects.all().order_by('-id')[0:4]
    sdata=service_provider.objects.all().order_by('discount_price')[0:12]
    md={'cdata':data,"servicedata":sdata}
    return render(request,'index.html',md)

def about(request):
    return render(request,'about.html')

def contact(request):
    md={}
    if request.method=="POST":
        a=request.POST.get("name")
        b=request.POST.get("email")
        c=request.POST.get("mobile")
        d=request.POST.get("msg")
        contactus(Name=a,Email=b,Mobile=c,Message=d).save()
        return HttpResponse("<script>alert('Thanks for contacting with us..');location.href='/contact/'</script>")
        #md={"name":a,"email":b,"mobile":c,"message":d}

    return render(request,'contact.html')

def register(request):
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        mobile=request.POST.get('mobile')
        passwd=request.POST.get('passwd')
        address=request.POST.get('address')
        pincod=request.POST.get('pincod')
        city=request.POST.get('city')
        picture=request.FILES['fu']
        tbl_register(name=name,email=email,mobile=mobile,passwd=passwd,address=address,pincod=pincod,city=city,picture=picture).save()
        return HttpResponse("<script>alert('');location.href='/profile/'</script>")

    return render(request,'register.html')



def servise(request):
    sid=request.GET.get('msg')
    sdata=service_provider.objects.all().filter(id=sid)
    servise=tbl_service.objects.all().filter(provider_name=sid)
    md={"sdata":sdata,"servise":servise}
    return render(request,'servise.html',md)

def login(request):
    if request.method=="POST":
        email=request.POST.get('email')
        password=request.POST.get('password')
        x=tbl_register.objects.filter(email=email,passwd=password)
        if x.count()==1:
           # x[0].name,x[0].picture,x[0].email
           request.session['name']=str(x[0].name)
           request.session['picture']=str(x[0].picture)
           request.session['email'] = str(x[0].email)
           return HttpResponse("<script>alert('Your welcom');location.href='/home/'</script>")
        else:
            return HttpResponse("<script>alert('Invalid Login');location.href='/login/'</script>")
        #select * from tbl_register where email=''
    return render(request,'login.html')

def faq(request):
    return render(request,'faq.html')

def logout(request):
    del request.session['email']
    return HttpResponse("<script>alert('Logged out');location.href='/login/'</script>")



def bookedhistory(request):
    cursor=connection.cursor()
    email=request.session.get('email')
    cursor.execute("select * from user_tbl_booking left join user_service_provider on user_tbl_booking.providerid=user_service_provider.id where user_tbl_booking.email='"+email+"' order by user_tbl_booking.id desc ")
    rows=cursor.fetchall()
    print(rows)
    md={"data":rows}
    return render(request,'bookedhistory.html',md)


def profile(request):
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        mobile=request.POST.get('mobile')
        passwd=request.POST.get('passwd')
        address=request.POST.get('address')
        pincod=request.POST.get('pincod')
        city=request.POST.get('city')
        picture=request.FILES['fu']
        tbl_register(name=name,email=email,mobile=mobile,passwd=passwd,address=address,pincod=pincod,city=city,picture=picture).save()
        return HttpResponse("<script>alert('');location.href='/profile/'</script>")
    user=request.session.get('email')
    data=tbl_register.objects.all().filter(email=user)
    md={"userinfo":data}
    return render(request,'profile.html',md)


def allservices(request):      
    cid=request.GET.get('cid')
    searchdata=request.GET.get('search') #wash

    cdata=category.objects.all().order_by('-id')
    data=""

    if cid is not None:
        data=service_provider.objects.all().filter(service_category=cid)

    elif  searchdata is not None:
        data=service_provider.objects.all().filter(Q(service_name__icontains=searchdata) | Q(address__icontains=searchdata) | Q(city__icontains=searchdata) | Q(availability__icontains=searchdata) | Q(service_category__category_name__icontains=searchdata))
    else:
        data=service_provider.objects.all().order_by('-id')
    md={"cdata":cdata,"servicedata":data}
    return render(request,'allservices.html',md)



def booking(request):

    email=request.session.get('email')

    if email is not None:
        if request.method=="POST":
            date=request.POST.get('date')
            time=request.POST.get('time')
            city=request.POST.get('city')
            pincode= request.POST.get('pincode')
            payment=request.POST.get('payment')
            address= request.POST.get('address')
            detail=request.POST.get('detail')
            now=datetime.today().strftime('%Y-%m-%d')
            provider=request.POST.get('provider')
            status=request.POST.get('status')
            tbl_booking(providerid=provider,email=email,date=date,payment=payment,time=time,detail=detail,address=address,city=city,pincode=pincode,reqdate=now,status='Panding').save()
            return HttpResponse("<script>alert('Your Booking Sent Sucessfully');location.href='/login/'</script>")

        return render(request,'booking.html')
    else:
        return HttpResponse("<script>alert('You need to loging ');location.href='/login/'</script>")