from django.urls import path

from.import views

urlpatterns=[
    path('',views.index),
    path('home/',views.index),
    path('about/',views.about),
    path('contact/', views.contact),
    path('faq/', views.faq),
    path('register/', views.register),
    path('servise/', views.servise),
    path('login/', views.login),
    path('logout/',views.logout),
    path('bookedhistory/',views.bookedhistory),
    path('profile/',views.profile),
    path('allservices/',views.allservices),
    path('booking/',views.booking),
]